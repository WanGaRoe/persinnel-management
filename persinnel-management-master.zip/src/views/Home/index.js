import Home from './Home.vue'

export default Home
